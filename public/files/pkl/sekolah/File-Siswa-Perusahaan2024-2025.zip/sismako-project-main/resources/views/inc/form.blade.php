<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title>Dashboard Guru</title>
    <link rel="stylesheet" href="{{asset('dist/css/tabler.min.css')}}">
    <style>
      .step {
          display: none;
      }
      .step.active {
          display: block;
      }
  </style>
  </head>